# Goals
- [x] Display the creation date of the OS
- [x] Create configuration file
- [x] Create package in AUR
- [x] Create noorfetch installer
- [x] Create initial ASCII art
- [x] Create a colour for ASCII art
- [x] Update configuration file
- [ ] Display the package quantity
- [ ] Create --pallete/-p flag

